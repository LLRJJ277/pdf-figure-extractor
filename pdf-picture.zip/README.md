# PDF Figure Extractor (PDF 图表提取工具)

这是一个专门为 SCI 论文设计的 PDF 图表提取工具。它可以自动识别并提取 PDF 文件中的嵌入图像，并提供便捷的一键复制功能。

## 核心功能
- **全量提取**：自动提取 PDF 中的所有位图图像。
- **一键复制**：点击提取出的图片即可直接复制到剪贴板，方便粘贴到 Word、微信或编辑器中。
- **静默通知**：采用非阻塞式气泡提示，操作流畅。
- **轻量化**：基于 FastAPI 和 PyMuPDF，响应速度快。

## 快速开始

### 1. 安装依赖
确保您的电脑已安装 Python 3.8+，然后在终端运行：
```bash
pip install -r requirements.txt
```

### 2. 启动服务
```bash
uvicorn server.main:app --reload
```

### 3. 使用工具
在浏览器中访问：`http://localhost:8000`

## 技术栈
- **后端**: FastAPI, PyMuPDF (fitz), Pillow
- **前端**: 原生 JavaScript, CSS3 (Flexbox/Grid)

## 许可证
MIT License
