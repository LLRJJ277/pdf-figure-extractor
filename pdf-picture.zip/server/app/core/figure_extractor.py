"""
Figure Extractor Module
"""
import fitz  # PyMuPDF
import cv2
import numpy as np
from PIL import Image
import os
import io
from typing import List, Dict, Any
from pathlib import Path


class FigureExtractor:
    """图表提取器"""
    
    def __init__(self, pdf_path: str, output_dir: str = "outputs"):
        self.pdf_path = pdf_path
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
    
    def extract_figures(self) -> List[Dict[str, Any]]:
        """提取PDF中的所有图表"""
        doc = fitz.open(self.pdf_path)
        figures = []
        
        for page_num in range(len(doc)):
            page = doc[page_num]
            
            # 获取页面上的所有图像
            image_list = page.get_images(full=True)
            
            for img_idx, img in enumerate(image_list):
                xref = img[0]
                
                # 提取图像
                base_image = doc.extract_image(xref)
                image_bytes = base_image["image"]
                
                # 保存图像
                figure_id = f"fig_{page_num+1}_{img_idx+1}"
                output_path = os.path.join(
                    self.output_dir, 
                    f"{figure_id}.png"
                )
                
                # 将字节转换为图像
                image = Image.open(io.BytesIO(image_bytes))
                image.save(output_path)
                
                figures.append({
                    "figure_id": figure_id,
                    "page": page_num + 1,
                    "path": output_path,
                    "width": base_image.get("width", 0),
                    "height": base_image.get("height", 0)
                })
        
        doc.close()
        return figures
