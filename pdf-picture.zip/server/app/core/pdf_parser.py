"""
PDF Parser Module
"""
import fitz  # PyMuPDF
from typing import List, Dict, Any


class PDFParser:
    """PDF解析器"""
    
    def __init__(self, pdf_path: str):
        self.pdf_path = pdf_path
        self.doc = None
    
    def open(self):
        """打开PDF文件"""
        self.doc = fitz.open(self.pdf_path)
        return self
    
    def close(self):
        """关闭PDF文件"""
        if self.doc:
            self.doc.close()
    
    def __enter__(self):
        self.open()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
    
    def parse(self) -> List[Dict[str, Any]]:
        """解析PDF，返回页面信息"""
        if not self.doc:
            self.open()
        
        pages = []
        for page_num in range(len(self.doc)):
            page = self.doc[page_num]
            
            # 获取页面尺寸
            rect = page.rect
            
            # 获取页面上的所有图像
            images = []
            image_list = page.get_images(full=True)
            for img_idx, img in enumerate(image_list):
                xref = img[0]
                base_image = self.doc.extract_image(xref)
                images.append({
                    "index": img_idx,
                    "xref": xref,
                    "width": base_image.get("width", 0),
                    "height": base_image.get("height", 0),
                    "colorspace": base_image.get("colorspace", 0),
                    "bpc": base_image.get("bpc", 0)
                })
            
            pages.append({
                "page_num": page_num + 1,
                "width": rect.width,
                "height": rect.height,
                "images": images
            })
        
        return pages
