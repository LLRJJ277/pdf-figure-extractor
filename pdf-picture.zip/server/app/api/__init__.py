from fastapi import FastAPI, UploadFile, File
from fastapi.responses import JSONResponse
import os
import tempfile

# Assuming FigureExtractor is available in the core module
from ..core.figure_extractor import FigureExtractor

# Initialize FastAPI app
app = FastAPI()

# Define a temporary directory for uploaded files
# Using a temporary directory for safety and automatic cleanup.
@app.post("/extract-figures/")
async def extract_figures_from_pdf(file: UploadFile = File(...)):
    """
    Upload a PDF file and extract figures from it.
    """
    if not file.filename.lower().endswith(".pdf"):
        return JSONResponse(status_code=400, content={"message": "Invalid file type. Please upload a PDF file."})

    try:
        # Create a temporary directory to store the uploaded PDF and extracted figures
        with tempfile.TemporaryDirectory() as tmpdir:
            pdf_save_path = os.path.join(tmpdir, file.filename)
            with open(pdf_save_path, "wb+") as file_object:
                file_object.write(await file.read())

            # Define output directory for extracted figures within the temporary directory
            figure_output_dir = os.path.join(tmpdir, "extracted_figures")
            os.makedirs(figure_output_dir, exist_ok=True)

            # Initialize FigureExtractor
            extractor = FigureExtractor(pdf_path=pdf_save_path, output_dir=figure_output_dir)
            extracted_figures = extractor.extract_figures()

            # The temporary directory and its contents will be automatically cleaned up
            # when exiting the 'with' block.

            return JSONResponse(content={
                "message": "Figures extracted successfully",
                "figures": extracted_figures
            })

    except Exception as e:
        # Log the error for debugging
        print(f"Error processing file {file.filename}: {e}")
        return JSONResponse(status_code=500, content={"message": f"An error occurred: {str(e)}"})

# Optional: Add a root endpoint for health check
@app.get("/")
async def read_root():
    return {"message": "PDF Figure Extractor API is running"}

# Initialize FastAPI app
app = FastAPI()

# Define a temporary directory for uploaded files
# Using a temporary directory for safety and automatic cleanup.
@app.post("/extract-figures/")
async def extract_figures_from_pdf(file: UploadFile = File(...)):
    """
    Upload a PDF file and extract figures from it.
    """
    if not file.filename.lower().endswith(".pdf"):
        return JSONResponse(status_code=400, content={"message": "Invalid file type. Please upload a PDF file."})

    try:
        # Create a temporary directory to store the uploaded PDF and extracted figures
        with tempfile.TemporaryDirectory() as tmpdir:
            pdf_save_path = os.path.join(tmpdir, file.filename)
            with open(pdf_save_path, "wb+") as file_object:
                file_object.write(await file.read())

            # Define output directory for extracted figures within the temporary directory
            figure_output_dir = os.path.join(tmpdir, "extracted_figures")
            os.makedirs(figure_output_dir, exist_ok=True)

            # Initialize FigureExtractor
            extractor = FigureExtractor(pdf_path=pdf_save_path, output_dir=figure_output_dir)
            extracted_figures = extractor.extract_figures()

            # The temporary directory and its contents will be automatically cleaned up
            # when exiting the 'with' block.

            return JSONResponse(content={
                "message": "Figures extracted successfully",
                "figures": extracted_figures
            })

    except Exception as e:
        # Log the error for debugging
        print(f"Error processing file {file.filename}: {e}")
        return JSONResponse(status_code=500, content={"message": f"An error occurred: {str(e)}"})

# Optional: Add a root endpoint for health check
@app.get("/")
async def read_root():
    return {"message": "PDF Figure Extractor API is running"}