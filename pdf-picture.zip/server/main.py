from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, HTMLResponse
import os
import uuid
from server.app.core.pdf_parser import PDFParser
from server.app.core.figure_extractor import FigureExtractor

app = FastAPI(title="PDF Figure Extractor API")

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 上传目录
UPLOAD_DIR = "uploads"
OUTPUT_DIR = "outputs"

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)


@app.get("/", response_class=HTMLResponse)
async def root():
    """主页，提供测试界面"""
    possible_paths = [
        os.path.join(os.path.dirname(__file__), "..", "test_ui.html"),
        os.path.join(os.getcwd(), "test_ui.html"),
        "test_ui.html"
    ]
    for path in possible_paths:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
    return "<h1>PDF Figure Extractor API is running</h1>"


@app.post("/api/upload")
async def upload_pdf(file: UploadFile = File(...)):
    """上传PDF文件"""
    if not file.filename.endswith('.pdf'):
        raise HTTPException(status_code=400, detail="只支持PDF文件")
    
    # 生成唯一文件名
    file_id = str(uuid.uuid4())
    file_path = os.path.join(UPLOAD_DIR, f"{file_id}_{file.filename}")
    
    try:
        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)
        
        return {"file_id": file_id, "filename": file.filename}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"文件上传失败: {str(e)}")


@app.post("/api/extract/{file_id}")
async def extract_figures(file_id: str):
    """提取图表"""
    # 查找上传的文件
    file_path = None
    for filename in os.listdir(UPLOAD_DIR):
        if filename.startswith(file_id):
            file_path = os.path.join(UPLOAD_DIR, filename)
            break
    
    if not file_path:
        raise HTTPException(status_code=404, detail="文件未找到")
    
    try:
        # 解析PDF
        parser = PDFParser(file_path)
        pages = parser.parse()
        
        # 提取图表
        extractor = FigureExtractor(file_path)
        figures = extractor.extract_figures()
        
        return {
            "file_id": file_id,
            "total_pages": len(pages),
            "figures": figures
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"提取失败: {str(e)}")


@app.get("/api/figure/{figure_id}")
async def get_figure(figure_id: str):
    """获取单个图表"""
    figure_path = os.path.join(OUTPUT_DIR, f"{figure_id}.png")
    
    if not os.path.exists(figure_path):
        raise HTTPException(status_code=404, detail="图表未找到")
    
    return FileResponse(figure_path, media_type="image/png")


@app.get("/api/download/{file_id}")
async def download_figures(file_id: str):
    """批量下载图表"""
    import zipfile
    
    # 创建临时ZIP文件
    zip_path = os.path.join(OUTPUT_DIR, f"{file_id}_figures.zip")
    
    with zipfile.ZipFile(zip_path, 'w') as zipf:
        for filename in os.listdir(OUTPUT_DIR):
            if filename.endswith('.png'):
                file_path = os.path.join(OUTPUT_DIR, filename)
                zipf.write(file_path, filename)
    
    return FileResponse(zip_path, filename=f"{file_id}_figures.zip", media_type="application/zip")
